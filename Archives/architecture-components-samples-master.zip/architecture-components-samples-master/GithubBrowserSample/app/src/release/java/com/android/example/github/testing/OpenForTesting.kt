package com.android.example.github.testing

@Target(AnnotationTarget.CLASS)
annotation class OpenForTesting
