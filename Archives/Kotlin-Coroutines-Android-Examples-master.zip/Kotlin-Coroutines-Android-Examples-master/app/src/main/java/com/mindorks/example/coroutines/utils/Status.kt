package com.mindorks.example.coroutines.utils

enum class Status {
    SUCCESS,
    ERROR,
    LOADING
}